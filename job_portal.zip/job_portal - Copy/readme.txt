i am doing my project in python so python so a python compiler must be installed
along with it Django must be installed 

1.install python 
2.install pycharm
3.install django
4.clone or download job_portal zip file
5.then extract the job_portal file
6.open pycharm and open job_poratl project file in pycharm

 ensure that the following packages are installed before you start the server 

package               version
asgiref               3.2.7
Django                3.0.5
django-crispy-forms   1.9.0
pip                   20.0.2
pytz                  2019.3
setuptools            46.1.3
sqlparse              0.3.1

if any package is not present
type the command "pip install packagename" in your terminal


7.for running this program 
enter the command    python manage.py runserver on your terminal
8.to open the website enter localhost:8000/   or the link appeared in the terminal

9.if you are new to the website click on signup text which is in the button and enter your details
in the field of usertype : enter jobseeker or job provider only
after succesfull registration click cross mark in the registration page

10. website then redirects to jobseeker homepage or job provider homepage depending on your usertype

11.job seeker will have options like searching job,saving job,applying job,checking status of the job,giving a compaign,unsaving job  etc....

12.job provider will have options like posting job,edit details of the job,accept or reject a job application,giving a complaint etc.......

13.the website dosent work if you login as jobeeker and go to urls of jobprovider and viceverse

14.if user is already logged in we have to logout the current user to open a new user account.

THIS IS BRIEF DESCRIPTION ABOUT THE WEBSITE AND THE INSTALLATIONS REQUIRED

my contact details are:
gmail :  pruthvikantevari@gmail.com
phone/whatsapp number : 8179637117
