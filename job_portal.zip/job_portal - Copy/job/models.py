from django.db import models
from django.contrib.auth.models import User

class vivaralu(models.Model):
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    email = models.EmailField()
    mobile = models.IntegerField()
    address = models.CharField(max_length=1000)
    city = models.CharField(max_length=100)
    pincode = models.IntegerField()
    password = models.CharField(max_length=100)
    user_type = models.CharField(default='jobseeker', max_length=100)

    def __str__(self):
        return(self.fname )


class job(models.Model):
    jobprovider = models.ForeignKey(User, on_delete=models.CASCADE,null=True)
    job_type = models.CharField(max_length=100)
    job_title = models.CharField(max_length=100)
    company = models.CharField(max_length=100)
    salary = models.IntegerField()
    location = models.CharField(max_length=100)
    description = models.CharField(max_length=1000)
    expierience = models.CharField(max_length=100)


class complaint(models.Model):
    manishi = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=100)
    messege = models.CharField(max_length=1000)

    def __str__(self):
        return(self.subject+" by "+self.name)


class savedjobs(models.Model):
    manishi = models.ForeignKey(User, on_delete=models.CASCADE,related_name='vidipanulu')
    pani = models.ForeignKey(job,on_delete=models.CASCADE,related_name = 'work')

    def __str__(self):
        return(self.manishi.username+"--"+str(self.id))


class CV(models.Model):
    cv =models.FileField()
    human = models.ForeignKey(User, on_delete=models.CASCADE, related_name='hiswork')
    work = models.ForeignKey(job, on_delete=models.CASCADE, related_name='kaam')

class application(models.Model):
    skills = models.CharField(max_length= 1000)
    status = models.CharField(default='pending',max_length= 1000)
    qualifications = models.CharField(max_length= 1000)
    humans = models.ForeignKey(User, on_delete=models.CASCADE, related_name='hisworks')
    works = models.ForeignKey(job, on_delete=models.CASCADE, related_name='kaams')

