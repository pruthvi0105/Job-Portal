from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from django.contrib.auth.models import User ,auth
from django.contrib.auth import authenticate,login,logout
from django.db.models import Q
from django.contrib import messages
from .models import vivaralu,job,complaint,savedjobs,CV,application
from .forms import editJobForm, CVForm
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage

def register(request):
    if request.method == 'POST' :
        v=vivaralu()
        v.fname = request.POST['fname']
        v.lname = request.POST['lname']
        v.username = request.POST['username']
        v.email = request.POST['email']
        v.mobile = request.POST['mobile']
        v.address = request.POST['address']
        v.pincode = request.POST['pin']
        v.user_type = request.POST['user_type']
        v.password = request.POST['password1']
        password2 = request.POST['password2']
        if (v.password==password2 and v.password != None ) :
            if User.objects.filter(username=v.username):
                messages.error(request,'username already taken')
                return render(request, 'job/newregister.html')
            else:
                user = User.objects.create_user(username=v.username, email=v.email, password=v.password, first_name=v.fname,
                                            last_name=v.lname)
                user.save()
                v.save()
                if (v.user_type == 'jobseeker'):
                    messages.success(request,'Succesfully Registered')
                    return render(request,'job/newregister.html')
                else:
                    return render(request,'job/newregister.html')
        else:
            messages.error(request,'enter the same password in two fields.')
            return render(request, 'job/newregister.html')
    else:
        messages.error(request,'')
        return render(request, 'job/newregister.html')


def signin(request):
    if request.user.is_authenticated:
        return redirect('/')
    else:
            if request.method == 'POST':
                user_name = request.POST['username']
                password = request.POST['pwd']
                user = auth.authenticate(username=user_name, password=password)
                if user is not None:
                    v = vivaralu.objects.get(username=user_name)
                    auth.login(request, user)
                    if(v.user_type=='jobseeker'):
                        return redirect('/homepageseeker')
                    else:
                        return redirect('/homepageprovider')
                else:
                    messages.error(request,'Invalid Credentials')
                    return render(request, 'job/login.html')
            else:
                return render(request, 'job/login.html')


def signout(request):
    logout(request)
    return redirect('/')


def seekerpage(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        all_jobs = job.objects.all()
        try:
            query1 = request.GET['company']
            query2 = request.GET['job_title']
            query3 = request.GET['salary']
            #if(query3 == NULL) :
            if query3:
                 all_jobs = job.objects.filter(Q(company__contains=query1)&Q(job_title__contains=query2) &Q(salary__range=(query3,10000000)))
            else:
                all_jobs = job.objects.filter(Q(company__contains=query1) & Q(job_title__contains=query2))
        finally:
            return render(request,'job/homepageseeker.html',{'all_jobs':all_jobs})




def providerpage(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobprovider'):
        if request.method == "POST":
            b=job()
            b.job_type = request.POST['jobtype']
            b.job_title = request.POST['jobtitle']
            b.company = request.POST['companyname']
            b.salary = request.POST['salary']
            b.location = request.POST['location']
            b.jobprovider = request.user
            b.description = request.POST['description']
            b.expierience = request.POST['expierience']
            b.save()
            messages.success(request, 'succesfull')
            return render(request,'job/com_homepage.html')
        else:
            return render(request, 'job/com_homepage.html')

def contact(request):
    peru = request.user.username
    his = vivaralu.objects.get(username=peru)
    histype = his.user_type
    if request.method == "POST":
        c=complaint()
        c.name = request.POST['name']
        c.email = request.POST['email']
        c.manishi = request.user
        c.messege = request.POST['message']
        c.subject = request.POST['subject']
        c.save()
        messages.success(request, 'complaint sent')

        if histype == "jobseeker":
            return render(request,'job/contactseeker.html')
        else :
            return render(request,'job/contactprovider.html')

    else:
        if histype == "jobseeker":
            return render(request,'job/contactseeker.html')
        else :
            return render(request,'job/contactprovider.html')

def savejob(request,id):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        nachinapani = job.objects.get(id = id)
        provider = nachinapani.jobprovider
        title = nachinapani.job_title
        check = savedjobs.objects.filter(manishi= request.user).filter(pani__jobprovider = provider).filter(pani__job_title = title)
        if check.count():
            messages.info(request,'job already saved')
        else:
            jobitem = savedjobs()
            jobitem.manishi = request.user
            jobitem.pani =nachinapani
            jobitem.save()
            messages.success(request,'JOB SAVED')

        return redirect('/homepageseeker')


def jobsaved(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        all_saved = savedjobs.objects.filter(manishi = request.user)
        return render(request,'job/savejob.html',{'all_saved':all_saved })

def unsave(request,id):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        savedjob = savedjobs.objects.get(id = id)
        savedjob.delete()
        messages.success(request,'JOB DELETED SUCCESFULLY')
        return redirect('/jobsaved')

def applyjob(request,id):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        if request.method == 'GET':
            return render(request, 'job/duplicate.html')

        if request.method == 'POST':
            jobs = job.objects.get(id = id)
            pruthvi = application()
            pruthvi.skills = request.POST['company']
            pruthvi.qualifications = request.POST['job_title']
            pruthvi.humans = request.user
            pruthvi.works = jobs
            pruthvi.save()
            messages.success(request,'job applied succesfully')
            return redirect('/homepageseeker')



def inboxseeker(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        adi = application.objects.filter(humans = request.user)
        return render(request,'job/inbox.html',{ 'adi':adi})

def inboxprovider(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobprovider'):
        satya = application.objects.filter(works__jobprovider= request.user)
        adi = []
        rohit = []
        for app in satya:
            if(app.status == "REJECTED"):
                pass
            elif(app.status == "pending"):
                adi.append(app)
            else:
                rohit.append(app)


        return  render(request,'job/com_inbox.html',{'adi':adi,'rohit':rohit})





def showPostedJobs(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobprovider'):
        profile = vivaralu.objects.filter(username=request.user.username).first()
        if profile.user_type == 'jobprovider':
            udyogalu = job.objects.filter(jobprovider=request.user).all()
            return render(request,'job/postedjobs.html',{'udyogalu':udyogalu})


def editJob(request,id):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobprovider'):
        udyogam = job.objects.get(pk=id)
        if udyogam.jobprovider == request.user:
            if request.method == 'POST':
                form = editJobForm(request.POST, request.FILES, instance=udyogam)
                if form.is_valid():
                    udyogam.save()
                    messages.success(request, 'Job edited successfully!')
                    return redirect('/postedjobs')
                else:
                    return render(request, 'job/editjob.html', {'form': form})
            else:
                form = editJobForm(instance=udyogam)
                return render(request,'job/editjob.html',{'form':form})

def call(request,id):
    appli = application.objects.get(id = id)
    appli.status = "called for interview "
    appli.save()
    return redirect('/homepageprovider')

def reject(request,id):
    appli = application.objects.get(id = id)
    appli.status = "REJECTED"
    appli.save()
    return redirect('/homepageprovider')

def seekerprofile(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        prof = vivaralu.objects.get(username=request.user.username)
        return render(request,'job/profile.html',{'prof': prof})

def providerprofile(request):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobprovider'):
        prof = vivaralu.objects.get(username=request.user.username)
        return render(request,'job/mprofile.html',{'prof':prof})





def savedapply(request,id):
    userperu = request.user.username
    athadi_vivaralu = vivaralu.objects.get(username=userperu)
    athdi_type = athadi_vivaralu.user_type
    if (athdi_type == 'jobseeker'):
        if request.method == 'GET':
            return render(request, 'job/duplicate.html')

        if request.method == 'POST':
            jobs = savedjobs.objects.get(id = id)
            workks = jobs.pani
            pruthvi = application()
            pruthvi.skills = request.POST['company']
            pruthvi.qualifications = request.POST['job_title']
            pruthvi.humans = request.user
            pruthvi.works = workks
            pruthvi.save()
            messages.success(request,'job applied succesfully')
            jobs.delete()
            return redirect('/homepageseeker')
