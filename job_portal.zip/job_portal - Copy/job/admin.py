from django.contrib import admin
from .models import vivaralu,job,complaint,savedjobs,CV,application

admin.site.register(complaint)
admin.site.register(vivaralu)
admin.site.register(job)
admin.site.register(savedjobs)
admin.site.register(CV)
admin.site.register(application)

