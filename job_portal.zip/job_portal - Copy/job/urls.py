from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('register/',views.register,name='register'),
    path('logout/',views.signout,name='signout'),
    path('',views.signin,name='signin'),
    path('homepageseeker/',views.seekerpage,name='seekerpage'),
    path('homepageprovider/',views.providerpage,name='providerpage'),
    path('contact/',views.contact,name='contact'),
    path('savedjobs/<int:id>',views.savejob,name='savejob'),
    path('jobsaved/',views.jobsaved,name='jobsaved'),
    path('unsave/<int:id>',views.unsave,name='unsave'),
    path('applyjob/<int:id>',views.applyjob,name = 'applyjob'),
    path('postedjobs/',views.showPostedJobs,name='postedjobs'),
    path('editjob/<int:id>',views.editJob,name='editjob'),
    path('inboxseeker/',views.inboxseeker,name='inboxseeker'),
    path('inboxprovider/',views.inboxprovider,name='inboxprovider'),
    path('call/<int:id>',views.call,name='call'),
    path('reject/<int:id>',views.reject,name='reject'),
    path('seekerprofile/',views.seekerprofile,name='seekerprofile'),
    path('savedapply/<int:id>',views.savedapply,name = 'savedapply'),
    path('providerprofile',views.providerprofile,name = 'providerprofile')


    ]
if settings.DEBUG:
    urlpatterns +=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)