from .models import vivaralu,job,complaint,savedjobs,CV
from django import forms
from django.forms import ModelForm


class editJobForm(forms.ModelForm):
    class Meta:
        model = job
        fields = ['company','job_title','job_type','location','description','salary','expierience']


class CVForm(forms.ModelForm):

    class Meta:
        model = CV
        fields = ['cv']